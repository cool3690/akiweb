
const DailyIframe = require('./module.js');
module.exports = DailyIframe.default;
