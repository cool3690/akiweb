import DailyJs from '../dist/daily-iframe.js';

let daily = new DailyJs();
daily.sayHello();

