const DailyIframe = require('../dist/daily-iframe.js');

var daily = new DailyIframe();
daily.sayHello();

