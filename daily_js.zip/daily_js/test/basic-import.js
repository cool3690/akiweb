import DailyIframe from '../dist/daily-iframe.js';

let daily = new DailyIframe();
daily.sayHello();

