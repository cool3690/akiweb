**🚨Our docs have moved! 🚨**

[Check them out here](https://docs.daily.co/docs) or jump to docs for our front-end javascript library and REST API, below.

- [Javascript docs](https://docs.daily.co/reference#using-the-dailyco-front-end-library): To add video calls to web pages and mobile apps
- [REST API docs](https://docs.daily.co/reference): To create video call rooms, configure features for the rooms, and manage users and permissions
